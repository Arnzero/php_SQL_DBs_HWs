-- Adrian Haro
-- CS 328 - Week 1 Lab

spool 328lab1-out.txt


prompt Adrian Haro

select * 
from dept;


spool off
