-- Adrian Haro
-- 325 HW 1 - using a table
prompt last modified 9-5-2019

spool 325hw1-out.txt

SELECT * from sports;

spool off

