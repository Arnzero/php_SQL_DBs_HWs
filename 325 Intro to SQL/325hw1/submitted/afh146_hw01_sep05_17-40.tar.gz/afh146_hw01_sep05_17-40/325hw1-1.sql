-- Adrian Haro
-- 325 HW 1 - my first table
-- last modified 9-5-2019

drop table sports

create table sports(
sports_id number(10),
sports_name varchar2(20),
sports_ball varchar2(20),
num_of_ppl_in_team  number(10),
primary key( sports_id)
);

prompt did it work?

-- Enter five rows

insert into sports values
(1, 'Basketball', 'Basketball', 12);
insert into sports values
(2, 'Baseball', 'Baseball', 9);
insert into sports values
(3, 'Tennis', 'Tennis Ball', 2);
insert into sports values
(4, 'Soccer', 'SoccerBall', 11);
insert into sports values
(5, 'Ping Pong', 'Poly Balls', 1);


select * from sports;

