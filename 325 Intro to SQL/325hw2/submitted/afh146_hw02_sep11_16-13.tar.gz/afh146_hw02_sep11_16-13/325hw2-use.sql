--Adrian Haro
--CS 325 Homework 2 - use tables
--last modified 09/09/2019


spool 325hw2-out.txt

prompt Adrian Haro
prompt Displaying Client table


describe Client;

select * from Client;


prompt Displaying Video table


describe Video;
select * from Video;


prompt Displaying Rental table


describe Rental;
select *from Rental;

spool off 
