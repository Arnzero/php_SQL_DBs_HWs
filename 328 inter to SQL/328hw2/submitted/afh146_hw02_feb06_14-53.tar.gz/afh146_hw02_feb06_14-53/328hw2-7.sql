--BUILT UPON Jesse Garcia Oil_Changes Database



--Adrian Haro
--CS 328 - Homework 2 - Problem 7
--2/5/2020

spool 328hw2-7-out.txt

prompt Adrian Haro

create or replace function valid_vehicle_year(carYrManu varchar2 returns boolean as

begin
	
	dbms_output.put_line('working' || to_char(sysdate, 'YYYY'));
	if carYrManu > to_char(sysdate, 'YYYY') then
		return 'FALSE';
	else
		return 'TRUE';
	end if;
	
end;
/
show errors


prompt this stored function checks to verify if the
prompt oil type preference has changed since last visit
prompt
prompt takes in car ID and latest oil type
prompt finds customer id then looks up last oil change type
prompt error in database design, EACH  car should have oil type
prompt since customers have many cars cannot check last car's oil type

create or replace function type_oil_change
	(curr_car_id char, curr_oil_type varchar2) return varchar2 as
last_oil_type   oil_change.oil_type%type;
curr_cust 	oil_change.customer_id%type;
begin
	select customer_id
	into curr_cust
	from car
	where curr_car_id = car_id;

	select oil_type
	into last_oil_type
	from oil_change
	where customer_id = curr_cust; 

	if last_oil_type <> curr_oil_type then
		return 'FALSE';
	else
		return 'TRUE';
	end if;

end;
/
show errors


spool off
